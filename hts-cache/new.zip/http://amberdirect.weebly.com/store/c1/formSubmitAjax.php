<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="1;url=/store/c1/Featured_Products.html" />

        <title>Redirecting to /store/c1/Featured_Products.html</title>
    </head>
    <body>
        Redirecting to <a href="/store/c1/Featured_Products.html">/store/c1/Featured_Products.html</a>.
    </body>
</html>